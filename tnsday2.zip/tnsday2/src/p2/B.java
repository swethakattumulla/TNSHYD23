
	package p2;
	import p1.*;
	public class B extends A
	{
	public static void main(String[] args)
	{
	B b1 = new B();
	b1.display();
	}
	}


