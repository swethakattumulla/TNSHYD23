package p3;


public class A
{
public void display()
{
System.out.println("Public program");
}
}