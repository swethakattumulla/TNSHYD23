package access;

public class P1 {

private void display()
{
	System.out.println("private program");
}
public static void main(String args[])
{
P1 p1 = new P1();
p1.display();
}

}
