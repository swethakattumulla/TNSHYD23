
package access;
 class P3
{
	void display()
	{
		System.out.println("default program");
	}
}
public class P2 {

	public static void main(String[] args) {
	P3 p3=new P3();
	p3.display();

	}

}

