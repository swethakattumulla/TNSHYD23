
package p4;
import p3.*;

class B extends  A
{
public static void main(String[] args)
{
A a = new A();
a.display();
}
}