package tnsday2;


public class Method {
	int a=2;
	static int b=4;
	int show() {
	return 0;
	}
	static void display()
	{
		System.out.println(b);
	
	}
	

	public static void main(String[] args) {
		int c=6;
		System.out.println(c);
		Method method=new Method();
		System.out.println(method.a);
		System.out.println(method.show());
		System.out.println(Method.b);
		Method.display();

		
	}

}
