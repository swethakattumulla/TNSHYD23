package tnsday2;
class Method2
{
	int a=4;
	static int b=6;
    int show()
	{
    	return 0;
	}
	static void display()
	{
		System.out.println(b);
	}

public class Method1 {

	public static void main(String[] args) {
		int c=2;
		System.out.println(c);
		Method2 method2 =new Method2();
		System.out.println(method2.a);
	    System.out.println(method2.show());
		System.out.println(Method2.b);
		Method2.display();
	}
}

}
		
		

	


