package tnsday2;
 class B
{
	int b=4;
	static int c=6;
}

public class A{

	public static void main(String[] args) {
		int c=2;
		System.out.println(c);
		B b1=new B();
		System.out.println(b1.b);
		System.out.println(B.c);
		

	}

}
