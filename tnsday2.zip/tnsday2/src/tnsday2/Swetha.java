package tnsday2;

public class Swetha 
{
	int b=4;
	static int c=6;
public static void main(String[] args) {
		int a=2;
		System.out.println(a);
		Swetha swetha=new Swetha();
		
		System.out.println(swetha.b);
		System.out.println(c);
		
	}

}
