package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.OrderDetails;

public interface ShoppingMallService {

	Object saveOrderDetails(OrderDetails shop);

	List<OrderDetails> fetchOrderDetailsList();

	OrderDetails fetchOrderDetailsById(Long id);

	void deletePlacementById(Long id);



}
