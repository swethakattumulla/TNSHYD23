package com.example.demo.controller;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.config.ConfigDataResourceNotFoundException;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.OrderDetails;

import com.example.demo.service.ShoppingMallService;

@RestController
public class ShoppingMallController {
	@Autowired
    ShoppingMallService service;
	@PostMapping("/shop")
	public Object orderDetais(@RequestBody OrderDetails shop) {
    	
    	return service.saveOrderDetails(shop);
		
	}
	
	@GetMapping("/shop")
    public List<OrderDetails> fetchordDetails() {
        //LOGGER.info("Inside fetchDepartmentList of DepartmentController");
        return service.fetchOrderDetailsList();
	}
	@GetMapping("/shop/{id}")
    public OrderDetails fetchOrderDetailsByIDetails(@PathVariable("id") Long id)
            {
        return service.fetchOrderDetailsById(id);
    }
	@DeleteMapping("/shop/{id}")
	public String deletePlacementById(@PathVariable("id") Long id) {
		  service.deletePlacementById(id);
	        return "Order details deleted Successfully!!";
	    }
	
	
	@PutMapping("/shop/{id}")
	public OrderDetails updateOrderDetails(@PathVariable("id") Long id, @RequestBody OrderDetails orderDetails) {
	    // Fetch the existing order details by ID
	    OrderDetails existingOrderDetails = service.fetchOrderDetailsById(id);
	    
	    // Update the fields with the new values from the request
	    existingOrderDetails.setDateOfPurchase(orderDetails.getDateOfPurchase());
	    existingOrderDetails.setTotal(orderDetails.getTotal());

	    // Save the updated order details back to the database
	    return (OrderDetails) service.saveOrderDetails(existingOrderDetails);
	}


}
