package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.example.demo.entity.OrderDetails;
import com.example.demo.repository.ShoppingMallRepository;


@Service
public class ShoppingMallServiceImpl implements ShoppingMallService{
	@Autowired
	private ShoppingMallRepository repository;

	@Override
	public Object saveOrderDetails(OrderDetails shop) {
		// TODO Auto-generated method stub
		return repository.save(shop);
	}

	@Override
	public List<OrderDetails> fetchOrderDetailsList() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public OrderDetails fetchOrderDetailsById(Long id) {
		// TODO Auto-generated method stub
		return repository.findById(id).get();
	}

	@Override
	public void deletePlacementById(Long id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
	}
	
	
}

	

	
